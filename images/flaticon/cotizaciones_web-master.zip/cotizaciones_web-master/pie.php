</div>
<footer class="footer text-center d-print-none">
    <div class="container">
        <span class="text-muted">Generador de cotizaciones y presupuestos. Creado y mantenido por <strong><a
                        target="_blank" href="https://parzibyte.me">parzibyte</a></strong></strong>.
            <br>
            Visita el <a target="_blank" href="https://github.com/parzibyte/cotizaciones_web">Repositorio en GitHub <i
                        class="fa fa-github"></i></a>
        </span>
    </div>
</footer>

</body>

</html>