<div class="col-12" style="padding-top: 1rem;">
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <ins class="adsbygoogle"
        style="display:block"
        data-ad-client="<?php echo Comun::env("AD_CLIENT") ?>"
        data-ad-slot="<?php echo Comun::env("AD_SLOT") ?>"
        data-ad-format="auto"
        data-full-width-responsive="true">
    </ins>
    <script>
    (adsbygoogle = window.adsbygoogle || []).push({});
    </script>
</div>
