<?php
SesionService::cerrarSesion();
Utiles::redireccionar("login&mensaje=3");
?>